# test_env.py
from cryptography.hazmat.primitives.asymmetric import x25519
from nacl import signing
print("[SUCCESS] Cryptography and PyNaCl installed successfully!")
